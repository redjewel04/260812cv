# Warm CV - GitHub Pages

따뜻하고 부드러운 아이보리·로즈·브라운 계열의 1페이지 CV 웹사이트입니다.

## 수정할 곳
1. `index.html`에서 `이름을 입력하세요`를 본인 이름으로 변경
2. Email / GitHub / Location 수정
3. `images` 폴더에 프로필 사진을 넣고, 필요하면 PHOTO 영역을 `<img>` 태그로 교체
4. 실제 자격증, 교육 이력, 강의 경력은 확인된 내용만 추가

## GitHub Pages 게시
1. GitHub에서 새 repository 생성
2. 이 폴더의 `index.html`, `style.css`, `script.js`, `images`를 repository에 업로드
3. Repository의 Settings → Pages로 이동
4. Deploy from a branch 선택
5. `main` branch / `/ (root)` 선택 후 Save

## 구성
- About
- Education & Training
- Skills & Tools
- Projects
- Activities
- Contact

개인정보는 예시 자리표시자로 두었습니다.
